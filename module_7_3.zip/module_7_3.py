"""
    Ввиду того, что код в методе 'find' и 'count' отличается только результатом, можно объединить их в один метод
    добавив ключ по которому будет возвращаться тот или иной результат. Объединенный метод закомментировал
"""


class WordsFinder:
    def __init__(self, *file_names):
        self.file_names = file_names

    def get_all_words(self):
        all_words = {}
        punct = [',', '.', '=', '!', '?', ';', ':', ' - ']
        for file_name in self.file_names:
            with open(file_name, 'r', encoding='utf-8') as file:
                s = file.read().replace('\n', ' ')
                for i in punct:
                    s = s.replace(i, ' ')
                s = s.lower().split()
                all_words[file.name] = s
        return all_words

    def find(self, word):
        result = {}
        all_words = self.get_all_words()
        for file_name, words in all_words.items():
            for word_ in words:
                if word.lower() == word_.lower():
                    result[file_name] = words.index(word_.lower()) + 1
                    break
        return result

    def count(self, word):
        result = {}
        all_words = self.get_all_words()
        for file_name, words in all_words.items():
            for word_ in words:
                if word.lower() == word_.lower():
                    result[file_name] = words.count(word_.lower())
        return result

#     def find_count(self, word, key):
#         result = {}
#         all_words = self.get_all_words()
#         for file_name, words in all_words.items():
#             for word_ in words:
#                 if word.lower() == word_.lower():
#                     if key == 'find':
#                         result[file_name] = words.index(word_) + 1
#                     if key == 'count':
#                         result[file_name] = words.count(word_.lower())
#         return result
#
# print('=' * 150)
# finder2 = WordsFinder('Walt Whitman - O Captain! My Captain!.txt',
#                       'Rudyard Kipling - If.txt',
#                       'Mother Goose - Monday’s Child.txt')
# print(finder2.find_count('the', 'find'))
# print(finder2.find_count('the', 'count'))


# ПРОВЕРКА НА ТЕСТОВОМ ФАЙЛЕ ИЗ ЗАДАНИЯ
finder2 = WordsFinder('test_file.txt')
print(finder2.get_all_words())  # Все слова
print(finder2.find('TEXT'))
print(finder2.count('teXT'))

# # ПРОВЕРКА НА ТРЕХ ФАЙЛАХ
# finder2 = WordsFinder('Walt Whitman - O Captain! My Captain!.txt',
#                       'Rudyard Kipling - If.txt',
#                       'Mother Goose - Monday’s Child.txt')
# print(finder2.get_all_words())  # Все слова
# print(finder2.find('THE'))
# print(finder2.count('the'))
